/****************************************************/
/* File: analyze.c                                  */
/* Semantic analyzer implementation                 */
/* for C-                                           */
/* Daniel Hideaki Makita 61651                      */
/****************************************************/

#include "globals.h"
#include "symtab.h"
#include "util.h"
#include "analyze.h"
#include <string.h>

/* counter for variable memory locations */
static int location = 0;

/* Procedure traverse is a generic recursive 
 * syntax tree traversal routine:
 * it applies preProc in preorder and postProc 
 * in postorder to tree pointed to by t
 */
static void traverse( TreeNode * t,
               void (* preProc) (TreeNode *),
               void (* postProc) (TreeNode *) )
{ if (t != NULL)
  { preProc(t);
    { int i;
      for (i=0; i < MAXCHILDREN; i++)
        traverse(t->child[i],preProc,postProc);
    }
    postProc(t);
    traverse(t->sibling,preProc,postProc);
  }
}

/* nullProc is a do-nothing procedure to 
 * generate preorder-only or postorder-only
 * traversals from traverse
 */
static void nullProc(TreeNode * t)
{ if (t==NULL) return;
  else return;
}

/* Procedure insertNode inserts 
 * identifiers stored in t into 
 * the symbol table 
 */
static void insertNode( TreeNode * t){ /*S� n�s declaracao ou parametro vao ter tipo, exp vai ter tipo = NULL*/
	int h;
	char*global;
	switch (t->nodekind){ 
    		case ExpK:
      			switch (t->kind.exp){
					case IdK:
						t->nameEscopo = copyString(t->attr.name); //Id + escopo
						strcat(t->nameEscopo, " ");
						strcat(t->nameEscopo, t->escopo);

						global = copyString(t->attr.name);
						strcat(global, " ");
						strcat(global, "Global");
						
						if(t->tipo==NULL){ //Nos de uso dos ids
							if(st_lookup(global)!=-1){ //No declarado global
								t->nameEscopo = copyString(global);
								st_insert(global, t->attr.name,t->tipo, t->escopo, t->VarVecFun,t->lineno,0);
							}else if(st_lookup(t->nameEscopo)!=-1){ //No declarado dentro da funcao
								st_insert(t->nameEscopo, t->attr.name,t->tipo, t->escopo, t->VarVecFun,t->lineno,0);
							}else{ //No nao declarado
								printf("\nErro Semantico, linha %d: %s nao definida.", t->lineno, t->attr.name);
							}
						}else{ //Nos de declaracao
							if(st_lookup(t->nameEscopo)==-1 && st_lookup(global)==-1){ //No nao declarado
								//Declaracao de variavel nao pode ser void, somente funcoes podem
								if(strcmp(t->tipo,"void")==0 && strcmp(t->VarVecFun, "funcao")!=0){
									printf("\nErro Semantico, linha %d: variavel %s definida com tipo void.", t->lineno, t->attr.name);
								}else{ //Insere na tabela	
									st_insert(t->nameEscopo, t->attr.name,t->tipo, t->escopo, t->VarVecFun,t->lineno,location++);
								}
							}else{ //Redefinicao de variavel
								printf("\nErro Semantico, linha %d: Redefinicao de %s.", t->lineno, t->attr.name);
							}
						}
				break;
        default:
          break;
      }
      break;
    default:
      break;
  }
}

/* Function buildSymtab constructs the symbol 
 * table by preorder traversal of the syntax tree
 */
void buildSymtab(TreeNode * syntaxTree)
{ traverse(syntaxTree,insertNode,nullProc);
  fprintf(listing,"\n\nTabela de Simbolos:\n");
	char*main = copyString("main");strcat(main," ");strcat(main,"Global");
	if(st_lookup(main)==-1) printf("\nErro Semantico, funcao main nao definida.");
}

static void typeError(TreeNode * t, char * message)
{ fprintf(listing,"Erro Semantico na linha %d: %s\n",t->lineno,message);
  Error = TRUE;
}

/* Procedure checkNode performs
 * type checking at a single tree node
 */
static void checkNode(TreeNode * t)
{ switch (t->nodekind)
  { 
    case StmtK:
      switch (t->kind.stmt)
      {case AtribK:
          if (strcmp(t->child[0]->tipo,"int")!=0)
            typeError(t->child[0],"assignment of non-integer value");
          break;
        default:
          break;
      }
      break;
    default:
      break;
  }
}

/* Procedure typeCheck performs type checking 
 * by a postorder syntax tree traversal
 */
void typeCheck(TreeNode * syntaxTree)
{ traverse(syntaxTree,nullProc,checkNode);
}
