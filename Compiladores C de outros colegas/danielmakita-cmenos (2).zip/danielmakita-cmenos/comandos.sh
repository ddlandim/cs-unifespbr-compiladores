#!/bin/bash

rm *.o

flex cmenos.l
bison -d cmenos.y
gcc -c *.c
gcc -o cmenos *.o -ly -lfl

./cmenos teste1.tny