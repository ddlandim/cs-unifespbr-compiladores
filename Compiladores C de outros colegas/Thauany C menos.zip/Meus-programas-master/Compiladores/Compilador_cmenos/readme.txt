Para compilar:
 $./compile.sh // é necessário ter o bison e flex instalado

Para rodar:
 $./cll <arquivo a ser compilado>
