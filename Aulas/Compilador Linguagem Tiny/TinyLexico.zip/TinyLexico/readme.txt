No prompt:

$ gcc -c *.c
$ gcc -o tiny *.o -ly -lfl

Execut�vel gerado � tiny